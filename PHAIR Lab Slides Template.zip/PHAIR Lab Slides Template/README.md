## This is the PHAIR Lab presentation template, expanded off of a publicly available beamer template called VK Presentation Template.

## This document is property of the PHAIR Lab and may not be shared outside the lab.
